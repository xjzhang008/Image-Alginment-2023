function [ L, E, X, Y ,dt_dual, iter] = sralt_inner_ladm_dct(D, J, lambda,p, tol, maxIter,rho0)

%D�ǳ�����Ӧ�仯֮��õ���
%TC :����ĵ��Ȳ���  

[m1 m2 m3] = size(D);
rank_adj = -1*ones(1,m3);
%rank_inc = 1*ones(1,m3);
rank_min = 10*ones(1,m3);
%rank_max = 20*ones(1,m3);

if nargin < 5
    error('Too few arguments') ;
end

if nargin <6
    tol = 1e-4 ;
elseif tol == -1
    tol = 1e-4 ;
end

if nargin < 7
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end
DISPLAY_EVERY=10;
tol=0.005;
rho=rho0;
alpha=1e-5;
beta=1e-5;
gamma=1e-5;
zeta=1e-5;
%��ʼ��E,dt_dual
coreNway=round(30*ones(1,m3));%��ʼ����[30,30,...,30]�������ǣ�   
E0 = zeros(m1,m2,m3);%��ʼ��E
L0 = D;
dt_dual0 = cell(1,m3); 
 for i = 1 : m3
        [r3,r4]=size(J{i});
        dt_dual0{i}=zeros(r4,1);       
end
dt_dual_matrix0 = zeros(m1*m2, m3); % dt_dual_matrix = [J_1*delta_1,...,J_n*delta_n]
dt_dual_tensor0 = reshape(dt_dual_matrix0,[m1 m2 m3]);


%% initialization X and Y
X0=cell(1,m3); 
Y0=cell(1,m3);

L0=dct(L0,[],3);
for i = 1:m3
    [Uk,Sigmak,Vk]=svds(L0(:,:,i),coreNway(i));
    X0{i} = Uk*Sigmak;
    Y0{i} = Vk';
end


d=0.95;

iter = 0;
converged = false;
while ~converged       
    iter = iter + 1;   
 %�任
D =dct(D,[],3);
E0=dct(E0,[],3);                                                                                                                                                                                        
dt_dual_tensor0=dct(dt_dual_tensor0,[],3);
    %% update (X,Y)
X=cell(1,m3); 
Y=cell(1,m3);
    for n = 1:m3
       [r1,r2]=size(Y0{n});
       X{n}=((D(:,:,n)+dt_dual_tensor0(:,:,n)-E0(:,:,n))*Y0{n}'+alpha*X0{n})*pinv(Y0{n}*Y0{n}'+(rho+alpha)*eye(r1));
       Y{n} = pinv(X{n}'*X{n}+eye(r1)*(rho+beta))*(X{n}'*(D(:,:,n)+dt_dual_tensor0(:,:,n)-E0(:,:,n))+beta*Y0{n});
       L(:,:,n) = X{n}*Y{n}; 
    end
%�Գ���ֻ��fft�����ž���
    %% adjust the rank of (X,Y)
    if rank_adj(n) == -1 && d<1
        max_k=max(coreNway);
        sum_k=sum(coreNway);
        sigmas=zeros(max_k*m3,1);
        for i=1:m3
            Xsq{i}=X{i}'*X{i};
            s = svd(Xsq{i});
            sigmas((i-1)*max_k+1:(i-1)*max_k+length(s))=s;
        end
        [dR,id]=sort(sigmas,'descend');
        drops = dR(1:sum_k-1)./dR(2:sum_k);
        [dmx,imx] = max(drops);
        rel_drp = (sum_k-1)*dmx/(sum(drops)-dmx);
        if rel_drp>10
            thold=d*sum(dR);
            iidx=0;ss=0;
            len=length(dR);
            for i=1:len
                ss=ss+dR(i);
                if(ss>thold)
                    iidx=i;
                    break;
                end
            end
            if(iidx>sum(rank_min(n)))
                idx=floor((id(iidx+1:sum_k)-1)/max_k);
                for n=1:m3
                    num=length(find(idx==n-1));
                    if(num>0)
                        if coreNway(n)-num>rank_min(n)
                            coreNway(n) = coreNway(n)-num;
                        else
                            coreNway(n) = rank_min(n);
                        end
                        [Qx,Rx] = qr(X{n},0);
                        [Qy,Ry] = qr(Y{n}',0);
                        [U,S,V] = svd(Rx*Ry');
                        sigv = diag(S);
                        X{n} = Qx*U(:,1:coreNway(n))*spdiags(sigv(1:coreNway(n)),0,coreNway(n),coreNway(n));
                        Y{n} = (Qy*V(:,1:coreNway(n)))';
                        L(:,:,n) = X{n}*Y{n};
                   end
                end
            end
            d=d*1.01;
        end
    end
 L=idct(L,[],3);
 D=idct(D,[],3);
 E0=idct(E0,[],3);                                                                                                                                                                                        
 dt_dual_tensor0=idct(dt_dual_tensor0,[],3);

    % update E
    temp =(1/(1+gamma))*(D+dt_dual_tensor0-L+gamma*E0); 
    E = solve_Lp(temp, lambda/(1+gamma), p );
  
    
    % update deltaTau
    H_wave = D-L-E; 
    H_wave3 = unfold(H_wave,3)';
    
    for i = 1 : m3
        %dt_dual{i}=-(inv(J{i}'*J{i}+eye(r4)*(rho+zeta)))*(J{i}'*H_wave3(:,i)+zeta*dt_dual0{i}); 
        dt_dual{i}=(inv(J{i}'*J{i}+eye(r4)*(rho+zeta)))*(zeta*dt_dual0{i}-J{i}'*H_wave3(:,i));
        dt_dual_matrix(:, i) = J{i}*dt_dual{i};
    end
    
 temp_dt_dual_tensor=reshape(dt_dual_matrix,[m1 m2 m3]);
 %%z_s
Z_s_norm=norm(unfold(dt_dual_tensor0-temp_dt_dual_tensor - gamma*(E-E0),3),'fro');
 %%z_tau
temp_dt_dual=norm(zeta*(cell2mat(dt_dual0)-cell2mat(dt_dual)),'fro');
 
%%z_x  z_y��F����
M1=D+temp_dt_dual_tensor-E-L;
M=dct(M1,[],3);
  
X2=cell(1,m3); 
Y2=cell(1,m3); 
for n = 1:m3
   X2{n}=rho*X{n}-M(:,:,n)*Y{n}';
   Y2{n}=rho*Y{n}-X{n}'* M(:,:,n);
end
X3=cell2mat(X2);
Y3=cell2mat(Y2');

%%��ĸ�ϵ�
X1=cell2mat(X);
Y1=cell2mat(Y');

stoppingCriterion=((norm(X3, 'fro')+norm(Y3, 'fro'))/m3+Z_s_norm+temp_dt_dual)/(1+norm(D(:), 'fro')+norm(X1, 'fro')+norm(Y1, 'fro')+norm(E(:), 'fro'));%E(:)��������������


    if  mod( iter, DISPLAY_EVERY) == -2
         disp(['#Iteration ' num2str(iter) '  rank(unfold(L,1)) ' num2str(rank(unfold(L,1))) ...
             '  rank(unfold(L,2)) ' num2str(rank(unfold(L,2)))  '  rank(unfold(L,3)) ' num2str(rank(unfold(L,3)))...
            ' ||E||_0 ' num2str(length(find(abs(E)>0)))  '  Stopping Criterion ' ...
             num2str(stoppingCriterion)]) ;
     end     
    
if stoppingCriterion <= tol
      converged = true ;
 end    
      
    if ~converged && iter >= maxIter
        converged = 1 ;       
    end

    %%
    X0 = X;
    Y0 = Y;
    E0 = E;
   dt_dual0=dt_dual;
  dt_dual_tensor0= temp_dt_dual_tensor;   

end
