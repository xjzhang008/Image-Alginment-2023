function StandCoordsTrans = ImgGenerator_Mixnoise(I0, thetaMax, TransMax, RotCenter, userName, StandCoords, IndImages, noisePara, Ex)
imgSize = size(I0);

if strcmp(noisePara.type, 'occlusion')
      block_l = noisePara.ratio;
end
if strcmp(noisePara.type, 'salt')
      ratio = noisePara.ratio;
end

savepath = [cd '\data\' userName 'Gauss_Theta' num2str(thetaMax) 'Ts' num2str(TransMax) noisePara.type  'Ex' num2str(Ex)]; 

if ~exist(savepath,'dir')
     mkdir(savepath);
end
numImages = length(IndImages);

theta =  (rand(1,numImages)-0.5)*thetaMax*pi/180;   % generate random angles
XT = (rand(1,numImages)-0.5)*TransMax;  % generate random x-translations
YT = (rand(1,numImages)-0.5)*TransMax;  % generate random y-translations

if exist([savepath '\StandCoordsInfo.mat'])
     load([savepath '\StandCoordsInfo.mat']);
else
    Transformations = cell(1,numImages);
    StandCoordsTrans = cell(1,numImages); 
end

I = cell(1,numImages);
Transformations1 = cell(1,numImages);
for i = 1:numImages
    xttemp = XT(i);
    yttemp = YT(i);
    thetatemp = theta(i);
    % Transformations1 is the similarity transformation centered as RotCenter
    Transformations1{i} = [cos(thetatemp) -sin(thetatemp) xttemp; sin(thetatemp) cos(thetatemp) yttemp; 0 0 1];
    StandCoordsTrans{IndImages(i)} = Transformations1{i}*(StandCoords-repmat([RotCenter;0],1,2)) + repmat([RotCenter;0],1,2);

    % Transformations is the similarity transformation centered as the left upper corner of images
    Transformations{IndImages(i)} = TwoPointSimilarity( StandCoords(1:2,:), StandCoordsTrans{IndImages(i)}(1:2,:));   
    Transformations{IndImages(i)}(3,:) = [ 0 0 1];
    Tfm = maketform('projective',Transformations{IndImages(i)}'); 
    I{i} = imtransform(I0, Tfm,'bicubic','XData',[1 imgSize(2)],'YData',[1 imgSize(1)],'Size',imgSize,'FillValues',255);  
    if strcmp(noisePara.type, 'occlusion')
        height     =   floor(sqrt(imgSize(1)*imgSize(2)*block_l));
        width      =   height;
        r_h = round( rand(1) * (imgSize(1) - height -1) ) + 1; 
        r_w = round( rand(1) * (imgSize(2) - width -1) ) + 1;  
        I{i} = Random_Block_Occlu(I{i},r_h, r_w, height, width); 
        I{i} = imnoise(I{i},'gaussian',0,0.01);
    end
    if strcmp(noisePara.type, 'salt')
        I{i} = imnoise(I{i},'salt & pepper',ratio);
        I{i} = imnoise(I{i},'gaussian',0,0.01);
    end
    
    if IndImages(i)<10
        imwritepath = [savepath '\00' num2str(IndImages(i)) '.png'];
    elseif IndImages(i)<100
        imwritepath = [savepath '\0' num2str(IndImages(i)) '.png'];
    else
        imwritepath = [savepath '\' num2str(IndImages(i)) '.png'];
    end
    imwrite(I{i},imwritepath);
end

% the outer eye corners of the first image are chosen and the same set of coordinates are
% used for all images to compute the initialized transformations
points = StandCoordsTrans{1}(1:2,:);
for i = IndImages
    if i<10
        pointspath = [savepath '\00' num2str(i) '-points.mat'];
    elseif i<100
        pointspath = [savepath '\0' num2str(i) '-points.mat'];
    else
        pointspath = [savepath '\' num2str(i) '-points.mat'];
    end
    save(pointspath,'points');
end
save([savepath '\StandCoordsInfo.mat'], 'StandCoordsTrans', 'Transformations');

end
