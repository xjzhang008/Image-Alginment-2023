
This code includes the detailed implementation of NTF-TTP2023 paper.

Ref:
''  Sijia Xia, Duo Qiu, and Xiongjun Zhang. Tensor Factorization via Transformed Tensor-Tensor Product for Image Alignment ''(NTF-TTP2023)


You can directly running 'go_digits_my_u.m' for digits_8 data.
go_digits_my_u.m    Figure 4(g) NTF-TTP in the paper




