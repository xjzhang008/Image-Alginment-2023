function Y = TU(U, Y)
O = tenmat(Y,[3]); % unfolding 
SS = O.data;
Y = U'*SS;
Y = tensor(tenmat(Y, O.rdims, O.cdims, O.tsize));
Y = Y.data;
end