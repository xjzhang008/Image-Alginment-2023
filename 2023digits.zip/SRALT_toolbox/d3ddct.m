function [F3] = d3ddct(topog); 
% 
% 
% 
% 3-d fft calculaton 
[x y z]=size(topog); 
for n=1:z 
      F1(:,:,n)=dct2(topog(:,:,n)); 
end 
for i=1:x 
    for j=1:y 
        for n1=1:z 
          k(n1)=[F1(i,j,n1)]; 
        end 
        k1=k.'; 
        F2=dct(k1); 
        for h=1:n1 
          F3(i,j,h)=F2(h); 
        end 
    end 
end

 