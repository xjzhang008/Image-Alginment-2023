% Xiaoqin Zhang, Di Wang, Zhengyuan Zhou��Yi Ma. May 2013. 
% Questions? zhangxiaoqinnan@gmail.com
%
% Copyright: the College of Mathematics and Information Sciences, Wenzhou University, Zhejiang
%            Microsoft Research Asia, Beijing
%
% Reference: Simultaneous Rectification and Alignment via Robust Recovery of Low-rank Tensors  
%            Xiaoqin Zhang, Di Wang��Zhengyuan Zhou��Yi Ma. Proc. of NIPS, 2013.
%

% Figure 4(d) in the paper


clc ;
clear all;
close all ;

% addpath
addpath SRALT_toolbox;  
addpath tensor_toolbox_2.6 ; 
addpath digitsdata;            
addpath results_real ;         

%% define images' path
currentPath = cd;        

imagePath = fullfile(currentPath,'digitsdata') ;
pointPath = fullfile(currentPath,'digitsdata') ; % path to files containing initial feature coordinates
userName = 'Digits_8' ;

destRoot = fullfile(currentPath,'results_real') ;
destDir = fullfile(destRoot,userName) ;
if ~exist(destDir,'dir')
    mkdir(destRoot,userName) ;
end

%% define parameters
sraltpara.DISPLAY = 0 ;
sraltpara.saveStart = 1 ;
sraltpara.saveEnd = 1 ;
sraltpara.saveIntermedia = 0 ;
%sraltpara.tau = [0.19 0.95] ; % the algorithm converges to the optimal solution when tau(1)<0.2 and tau(2)<1
% for Digit_3
sraltpara.canonicalImageSize = [ 29  29];
sraltpara.canonicalCoords = [ 5  24 ; ...
                             15 15  ];
% parametric tranformation model
sraltpara.transformType = 'EUCLIDEAN'; 
% one of 'TRANSLATION', 'EUCLIDEAN', 'SIMILARITY', 'AFFINE','HOMOGRAPHY'

sraltpara.numScales = 1 ; % if numScales > 1, we use multiscales;

% main loop
sraltpara.stoppingDelta = .01 ; % stopping condition of main loop
sraltpara.maxIter = 100 ; % maximum iteration number of main loops

% inner loop
sraltpara.inner_tol = 0.01; 
sraltpara.inner_maxIter = 200 ;        
sraltpara.continuationFlag = 1 ;  

sraltpara.rho0 = 0.25;
sraltpara.lambdac1 = 0.05;
sraltpara.lambdac2 = 0.15; 
sraltpara.p = 0.3;

%% Get training images
% get initial transformation
transformationInit = 'SIMILARITY' ;

[fileNames, transformations, numImages] = get_training_images( imagePath, pointPath, userName, sraltpara.canonicalCoords, transformationInit) ;

 %% Tensor main loop: do robust batch image alignment
tic
[Do,Z,A,E,X,Y, xi] = SRALT_U(fileNames, transformations, numImages, sraltpara, destDir) ;
toc

layout.xI = 10 ;
layout.yI = 10 ;  
layout.gap = 0 ;
layout.gap2 = 0 ;
my_plot(destDir, numImages, sraltpara.canonicalImageSize, layout) ;

